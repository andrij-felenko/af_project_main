#include "currencyByDate.h"
#include <QtCore/QDataStream>
#include <QtCore/QDateTime>
#include <QtCore/QJsonArray>
#include <QtCore/QJsonDocument>
#include <QtCore/QJsonObject>
#include <QtCore/QJsonValue>
#include <QtCore/QVariantList>
#include <QtCore/QFile>
#include <QtCore/QDebug>
#include <QtCore//QTimer>
#include <QtCore/QTimeZone>
#include <QtCore/QCoreApplication>
#include "dir.h"
#include "currencyUpdater.h"

using namespace CurrencyAF;
QString ByDate::pluginName = "Currency";
bool ByDate::is_static = false;

ByDate::ByDate(QObject *parent) : QObject(parent),
    m_fileName("currencyByDate.json"), date_format("yyyy-MM-dd")
{
    m_dir = AFlib::Dir(this).pluginData(pluginName);
    qDebug() << "Dir currency path" << m_dir.path();
    load();
}

QJsonObject ByDate::collectCurrency(QString name)
{
    QJsonObject obj;
    if (name.length() != 3)
        name = Type::toShort(name);
    obj.insert("currency", name);

    QJsonObject data;
    for (auto it : inst()->m_list)
        if (it.m_short == name)
            data.insert(it.m_date.toString(inst()->date_format), it.m_value);
    obj.insert("data", data);

    return obj;
}

QJsonArray ByDate::collectCurrency(QStringList names)
{
    QJsonArray array;
    for (auto it : names)
        array.push_back(inst()->collectCurrency(it));
    return array;
}

QJsonObject ByDate::collectLatest()
{
    QJsonObject obj;
    obj.insert("date", inst()->m_latestDateTime.date().toString(inst()->date_format));
    obj.insert("time", inst()->m_latestDateTime.time().toString("hh:mm:ss"));
    QJsonObject currencies;
    for (auto it : inst()->m_list)
        currencies.insert(it.m_short, it.m_value);

    obj.insert("currencies", currencies);
    return obj;
}

void ByDate::load()
{
    clear();

    // 468 sec
    auto timeStart = QDateTime::currentDateTime();
    QFile file(m_dir.absoluteFilePath(m_fileName.left(m_fileName.length() - 4) + "afd"));
    if (file.open(QIODevice::ReadOnly)){
        QByteArray array = file.readAll();
        QDataStream stream(array);

        int count;
        double v = 0.0;
        QDate d;
        QString s;

        // list
        stream >> count;
        for (int i = 0; i < count; i++){
//            if (i % 1000 == 0)
//                qDebug() << "Progress load list:" << i << "/" << count << " " << i * 100 / count;
            stream >> s >> d >> v;
            p_add(d, s, v, true);
        }
        qDebug() << timeStart.msecsTo(QDateTime::currentDateTime());

        // latest
        stream >> count;
        for (int i = 0; i < count; i++){
//            qDebug() << "Progress load latest list:" << i << "/" << count << " " << i * 100 / count;
            stream >> s >> d >> v;
            p_addLatest(d, s, v);
        }

        stream >> m_latestDateTime >> m_currencyList;
        m_currencyList.removeDuplicates();

        file.close();
    }
    else
        qDebug() << "File can`t read" << m_fileName;
}

bool ByDate::isCurrent(QDate date, AFlib::Continent cont)
{
    Q_UNUSED(date)
    int shift = 0;
    switch (cont) {
    case AFlib::Continent::Oceania:       shift =  8; break;
    case AFlib::Continent::East_Asia:     shift =  6; break;
    case AFlib::Continent::West_Asia:     shift =  3; break;
    case AFlib::Continent::Europe:        shift =  0; break;
    case AFlib::Continent::Africa:        shift = -1; break;
    case AFlib::Continent::South_America: shift = -5; break;
    case AFlib::Continent::North_America: shift = -7; break;
    default:;
    }

    auto needTime = QDateTime(QDate::currentDate(), QTime(11 + shift, 0),
                              QTimeZone::utc());
    return needTime.secsTo(QDateTime::currentDateTime()) >= 0;
}

void ByDate::p_updateLatest(QJsonObject data, QDateTime dTime)
{
    m_latest.clear();
    for (auto it = data.begin(); it != data.end(); ++it)
        p_add(dTime.date(), it.key(), it.value().toDouble());
    m_latestDateTime = dTime;
}

void ByDate::p_add(QDate date, QString m_short, double m_value, bool skipTest)
{
    if (not skipTest)
        for (auto it : m_list)
            if (it.m_date == date)
                if (it.m_short == m_short)
                    return;

    DateValue tmp;
    tmp.m_date = date;
    tmp.m_short = m_short;
    tmp.m_value = m_value;
    m_list.push_back(tmp);
}

void ByDate::p_removeDate(QDate date)
{
    m_list.erase(std::remove_if(m_list.begin(), m_list.end(),
                                [date](DateValue value){ return value.m_date == date; }),
                 m_list.end());
}

void ByDate::p_addLatest(QDate date, QString m_short, double m_value)
{
    for (auto it : m_latest)
        if (it.m_date == date)
            if (it.m_short == m_short)
                return;

    DateValue tmp;
    tmp.m_date = date;
    tmp.m_short = m_short;
    tmp.m_value = m_value;
    m_latest.push_back(tmp);
}

void ByDate::saveAsJson()
{
    QFile file(inst()->m_dir.absoluteFilePath(inst()->m_fileName));
    if (file.open(QIODevice::Truncate | QIODevice::ReadWrite)){
        QJsonObject obj;
        obj.insert("latest", collectLatest());
        obj.insert("data", inst()->collectCurrency(inst()->m_currencyList));
        qDebug() << "data.list" << obj.value("data").toArray().count()
                 << inst()->m_list.length() << inst()->m_currencyList.length();
        obj.insert("list", QJsonArray::fromStringList(inst()->m_currencyList));
        file.write(QJsonDocument(obj).toJson());
        file.close();
    }
    else
        qDebug() << "File can`t create" << inst()->m_fileName;
}

void ByDate::loadFromJson()
{
    QFile file(m_dir.absoluteFilePath(m_fileName));
    if (file.open(QIODevice::ReadOnly)) {
        //        inst()->clear();
        QJsonObject byte = QJsonDocument::fromJson(file.readAll()).object();
        QJsonObject latest = byte.value("latest").toObject();
        p_updateLatest(latest.value("currencies").toObject(),
                       QDateTime(QDate::fromString(latest.value("date").toString(), date_format),
                                 QTime::fromString(latest.value("time").toString(), "hh:mm:ss")));
        m_currencyList = byte.value("list").toVariant().toStringList();
        QJsonArray data = byte.value("data").toArray();
        int i = 0;
        int len = data.count();
        for (auto it = data.begin(); it != data.end(); ++it){
            qDebug() << i << "/" << len << "   " << int(i*100 / len) << "%";
            i++;
            auto current = it->toObject();
            QString currency = current.value("currency").toString();
            QJsonObject subObj = current.value("data").toObject();
            for (auto sub = subObj.begin(); sub != subObj.end(); ++sub)
                p_add(QDate::fromString(sub.key(), date_format), currency, sub.value().toDouble());
        }
        file.close();
        m_currencyList.removeDuplicates();
    }
    else
        qDebug() << "File can`t read" << m_fileName;
}

void ByDate::save()
{
    QFile file2(inst()->m_dir.absoluteFilePath(inst()->m_fileName.left(inst()->m_fileName.length() - 4) + "afd"));
    if (file2.open(QIODevice::Truncate | QIODevice::ReadWrite)){
        QDataStream stream(&file2);
        stream << inst()->m_list.length();
        for (auto it  = inst()->m_list.begin(); it != inst()->m_list.end(); ++it)
            stream << it->m_short << it->m_date << it->m_value;

        stream << inst()->m_latest.length();
        for (auto it  = inst()->m_latest.begin(); it != inst()->m_latest.end(); ++it)
            stream << it->m_short << it->m_date << it->m_value;

        stream << inst()->m_latestDateTime << inst()->m_currencyList;
        file2.close();
    }
}

void ByDate::add(QDate date, QString m_short, double m_value)
{
    inst()->p_add(date, m_short, m_value);
}

void ByDate::updateLatest(QJsonObject data, QDateTime dTime)
{
    inst()->p_updateLatest(data, dTime);
    inst()->save();
}

void ByDate::removeDate(QDate date)
{
    inst()->p_removeDate(date);
}

void ByDate::addCurrency(QString name)
{
    auto p_name = name;
    if (p_name.length() != 3)
        p_name = Type::toShort(p_name);

    if (not Type::allShort().contains(p_name)){
        qDebug() << QString("Currency %1 not found").arg(name);
        return;
    }

    inst()->m_currencyList.removeDuplicates();
    inst()->m_currencyList.push_back(p_name);
    Updater::currencies(p_name);
}

void ByDate::addCurrency(QStringList list)
{
    for (auto it : list)
        addCurrency(it);
}

void ByDate::removeCurrency(QString name)
{
    auto p_name = name;
    if (p_name.length() != 3)
        p_name = Type::toShort(p_name);

    if (not inst()->m_currencyList.contains(p_name)){
        qDebug() << QString("%1 not found in currency list.").arg(name);
        return;
    }

    inst()->m_currencyList.removeOne(p_name);
    inst()->m_list.erase(std::remove_if(inst()->m_list.begin(),
                                        inst()->m_list.end(),
                                        [p_name](DateValue value){
                                            return value.m_short == p_name;
                                        }),
                         inst()->m_list.end());
    inst()->save();
}

bool ByDate::foundDate(QDate date)
{
    for (auto it : inst()->m_list)
        if (it.m_date == date)
            return true;
    qDebug() << "Not found date" << date << inst()->m_list.length();
    return false;
}

ByDatePtr ByDate::inst()
{
    static ByDatePtr m_ptr;
    if (m_ptr.isNull())
        m_ptr = ByDatePtr::create(qApp);

    return m_ptr;
}

std::optional <double> ByDate::get(QString name, QDate date)
{
    for (auto it : inst()->m_list){
        if (it.m_date != date)
            continue;

        if (it.m_short == name)
            return it.m_value;

        if (name.length() != 3)
            if (it.m_short == Type::toFull(name))
                return it.m_value;
    }
    return std::nullopt;
}

void ByDate::clear()
{
    m_currencyList.clear();
    m_list.clear();
    m_latest.clear();
    m_latestDateTime = QDateTime();
}
