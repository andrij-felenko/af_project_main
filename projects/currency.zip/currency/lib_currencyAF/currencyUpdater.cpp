#include "currencyUpdater.h"
#include <QtCore/QDebug>
#include <QtCore/QJsonDocument>
#include <QtCore/QJsonObject>
#include <QtCore/QDebug>
#include <QtNetwork/QNetworkReply>
#include "currencyByDate.h"
#include "setting.h"
#include <QtCore/QCoreApplication>

using namespace CurrencyAF;

Updater::Updater(QObject *parent) : QNetworkAccessManager(parent),
    m_url(AFlib::Setting::value("currency_server").value().toString())
{
    QObject::connect(this, &QNetworkAccessManager::finished, this, &Updater::onRead);
}

void Updater::date(const QDate &date, QStringList curList)
{
    //
}

void Updater::currencies(QString name)
{
    //
}

void Updater::latest()
{
    //
}

CurrencyAF::UpdaterPtr Updater::instance()
{
    static UpdaterPtr m_ptr;
    if (m_ptr.isNull())
        m_ptr = UpdaterPtr::create(qApp);

    return m_ptr;
}

//void Updater::request()
//{
//    auto inst = CurrencyAF::Updater::instance();
//    QNetworkRequest request;
//    request.setUrl(QUrl(inst->m_url));
//    inst->get(request);
//}

//void Updater::request(QDate date)
//{
//    auto inst = CurrencyAF::Updater::instance();
//    QNetworkRequest request;
//    request.setUrl(QUrl(inst->m_url + date.toString("yyyy-MM-dd") + inst->m_accesKey));
//    inst->get(request);
//}

void Updater::onRead(QNetworkReply *reply)
{
//    QJsonObject obj = QJsonDocument::fromJson(reply->readAll()).object();
//    QDate date = QDate::fromString(obj.value("date").toString(), "yyyy-MM-dd");
//    QString base = obj.value("base").toString();
//    QJsonObject rateObj = obj.value("rates").toObject();
//    QStringList possibleList = Type::allShort();
//    for (auto m_short : rateObj.keys())
//        if (possibleList.contains(m_short))
//            ByDate::add(date, m_short, rateObj.value(m_short).toDouble());
//    ByDate::save();

//    testEqual(rateObj);
}
