#ifndef CURRENTCURRENCYBYDATE_H
#define CURRENTCURRENCYBYDATE_H

#include <QtCore/QDateTime>
#include <QtCore/QDir>
#include <QtCore/QObject>
#include "currencyType.h"

namespace CurrencyAF {
    class ByDate;
    typedef QSharedPointer <ByDate> ByDatePtr;
}

class CurrencyAF::ByDate : public QObject
{
    Q_OBJECT
public:
    explicit ByDate(QObject* parent = nullptr);
    static QString pluginName;

    /*static */QJsonObject collectCurrency(QString name);
    /*static */QJsonArray collectCurrency(QStringList names);
    static QJsonObject collectLatest();
    static std::optional <double> get(QString name, QDate date = QDate::currentDate());

    static void save();
    static void saveAsJson();
    static void add(QDate date, QString m_short, double m_value);
    static void updateLatest(QJsonObject data, QDateTime dTime = QDateTime::currentDateTime());
    static void removeDate(QDate date);

    static void addCurrency(QString name);
    static void addCurrency(QStringList list);
    static void removeCurrency(QString name);
    static bool foundDate(QDate date);

private:
    ByDate(ByDate const&) = delete;
    static ByDatePtr inst();
    void operator =(ByDate const&) = delete;

    void load();
    void clear();
    bool isCurrent(QDate date, AFlib::Continent cont);
    void p_updateLatest(QJsonObject data, QDateTime dTime = QDateTime::currentDateTime());
    void p_add(QDate date, QString m_short, double m_value, bool skipTest = false);
    void p_removeDate(QDate date);
    void p_addLatest(QDate date, QString m_short, double m_value);
    void loadFromJson();

    struct DateValue {
        QDate m_date;
        QString m_short;
        double m_value;
    };
    QStringList m_currencyList;
    QList <DateValue> m_list;
    QList <DateValue> m_latest;
    QDateTime m_latestDateTime;
    QString m_fileName;
    QDir m_dir;
    QString date_format;

    static bool is_static;
};

#endif // CURRENTCURRENCYBYDATE_H
