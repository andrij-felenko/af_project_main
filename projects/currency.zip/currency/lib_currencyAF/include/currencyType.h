#ifndef CURRENCYAFTYPE_H
#define CURRENCYAFTYPE_H

#include <QtCore/QList>
#include <QtCore/QString>
#include "enumAF.h"

namespace CurrencyAF {
class Type {
public:
    enum class Enum {
        // Africa
        South_African_Rand = 0xA00, // ZAR
        Kenyan_Shilling,      // KES
        Egyptian_Pound,       // EGP
        Moroccan_Dirham,      // MAD
        CFA_Franc,            // XOF
        Nigerian_Naira ,      // NGN
        Tunisian_Dinar,       // TND
        Ugandan_Shilling,     // UGX
        Central_African,      // XAF
        Libyan_Dinar,         // LYD
        Mauritian_Rupee,      // MUR
        Ghanaian_Cedi,        // GHS
        Angolan_Kwanza,       // AOA
        Tanzanian_Shilling,   // TZS
        Zimbabwean_Dollar,    // ZWD
        Botswana_Pula,        // BWP
        Algerian_Dinar,       // DZD
        Ethiopian_Birr,       // ETB
        Namibian_Dollar,      // NAD
        Sudanese_Pound,       // SDG
        Malagasy_Ariary,      // MGA
        Mozambican_Metical,   // MZN
        Seychellois_Rupee,    // SCR
        Sierra_Leonean_Leone, // SLL
        Malawian_Kwacha,      // MWK
        Gambian_Dalasi,       // GMD
        Burundian_Franc,      // BIF
        Somali_Shilling,      // SOS
        Guinean_Franc,        // GNF
        Congolese_Franc,      // CDF
        Sao_Tomean_Dobra,     // STD
        Basotho_Loti,         // LSL
        Liberian_Dollar,      // LRD
        Mauritanian_Ouguiya,  // MRU
        Swazi_Lilangeni,      // SZL
        Cape_Verdean_Escudo,  // CVE
        Rwandan_Franc,        // RWF
        Djiboutian_Franc,     // DJF
        Comorian_Franc,       // KMF
        Eritrean_Nakfa,       // ERN
        Saint_Helenian_Pound, // SHP
        Zambian_Kwacha,       // ZMW

        // Asia
        Indian_Rupee = 0xB00,  // INR
        Singapore_Dollar,      // SGD
        Malaysian_Ringgit,     // MYR
        Japanese_Yen,          // JPY
        Chinese_Yuan,          // CNY
        Thai_Baht,             // THB
        Emirati_Dirham,        // AED
        Hong_Kong_Dollar,      // HKD
        Turkish_Lira,          // TRY
        Philippine_Piso,       // PHP
        Indonesian_Rupiah,     // IDR
        Saudi_Arabian_Riyal,   // SAR
        South_Korean_Won,      // KRW
        Iraqi_Dinar,           // IQD
        Armenian_Dram,         // AMD
        Azerbaijan_Manat,      // AZN
        Georgian_Lari,         // GEL
        Kuwaiti_Dinar,         // KWD
        Russian_Ruble,         // RUB
        Pakistani_Rupee,       // PKR
        Israeli_Shekel,        // ILS
        Qatari_Riyal,          // QAR
        Omani_Rial,            // OMR
        Taiwan_New_Dollar,     // TWD
        Vietnamese_Dong,       // VND
        Jordanian_Dinar,       // JOD
        Bahraini_Dinar,        // BHD
        Sri_Lankan_Rupee,      // LKR
        Bangladeshi_Taka,      // BDT
        Uzbekistani_Som,       // UZS
        Iranian_Rial,          // IRR
        Syrian_Pound,          // SYP
        Afghan_Afghani,        // AFN
        Lebanese_Pound,        // LBP
        Nepalese_Rupee,        // NPR
        Lao_Kip,               // LAK
        Bruneian_Dollar,       // BND
        Macau_Pataca,          // MOP
        Kazakhstani_Tenge,     // KZT
        Yemeni_Rial,           // YER
        Maldivian_Rufiyaa,     // MVR
        Mongolian_Tughrik,     // MNT
        Tajikistani_Somoni,    // TJS
        North_Korean_Won,      // KPW
        Burmese_Kyat,          // MMK
        Kyrgyzstani_Som,       // KGS
        Cambodian_Riel,        // KHR
        Bhutanese_Ngultrum,    // BTN
        Turkmenistani_Manat,   // TMT

        // Europe
        Euro = 0xC00,      // EUR
        British_Pound,     // GBP
        Swiss_Franc,       // CHF
        Hungarian_Forint,  // HUF
        Swedish_Krona,     // SEK
        Norwegian_Krone,   // NOK
        Danish_Krone,      // DKK
        Polish_Zloty,      // PLN
        Czech_Koruna,      // CZK
        Ukrainian_Hryvnia, // UAH
        Romanian_Leu,      // RON
        Belarusian_Ruble,  // BYR
        New_Belarusian_Ruble, // BYN
        Croatian_Kuna,     // HRK,
        Bulgarian_Lev,     // BGN
        Icelandic_Krona,   // ISK
        Albanian_Lek,      // ALL
        Bosnian_Convertible_Marka, // BAM
        Serbian_Dinar,     // RSD
        Gibraltar_Pound,   // GIP
        Moldovan_Leu,      // MDL
        Macedonian_Denar,  // MKD
        Dutch_Guilder,     // ANG
        Seborgan_Luigino,  // SPL
        Jersey_Pound,      // JEP
        Isle_of_Man_Pound, // IMP
        Guernsey_Pound,    // GGP

        // North America
        US_Dollar = 0xD00,  // USD
        Canadian_Dollar,    // CAD
        Mexican_Peso,       // MXN
        Dominican_Peso,     // DOP,
        Costa_Rican_Colon,  // CRC,
        Jamaican_Dollar,    // JMD
        Trinidadian_Dollar,         // TTD
        East_Caribbean_Dollar,      // XCD
        Guatemalan_Quetzal,         // GTQ
        Barbadian_or_Bajan_Dollar,  // BBD
        Cuban_Convertible_Peso,     // CUC
        Honduran_Lempira,           // HNL
        Nicaraguan_Cordoba,         // NIO
        Bermudian_Dollar,           // BMD
        Panamanian_Balboa,          // PAB
        Caymanian_Dollar,           // KYD
        Belizean_Dollar,            // BZD
        Haitian_Gourde,             // HTG
        Cuban_Peso,                 // CUP
        Salvadoran_Colon,           // SVC
        Bahamian_Dollar,            // BSD
        IMF_Special,                // XDR
        Aruban_or_Dutch_Guilder,    // AWG

        // Oceania
        Australian_Dollar = 0xE00, // AUD
        New_Zealand_Dollar,        // NZD
        Fijian_Dollar,             // FJD
        CFP_Franc,                 // XPF
        Papua_New_Guinean_Kina,    // PGK
        Solomon_Islander_Dollar,   // SBD
        Tongan_Paanga,             // TOP
        Ni_Vanuatu_Vatu,           // VUV
        Samoan_Tala,               // WST
        Tuvaluan_Dollar,           // TVD

        // South America
        Brazilian_Real = 0xF00, // BRL
        Colombian_Peso,         // COP
        Chilean_Peso,           // CLP
        Argentine_Peso,         // ARS
        Peruvian_Sol,           // PEN
        Venezuelan_Bolivar,     // VES
        Uruguayan_Peso,         // UYU
        Bolivian_Boliviano,     // BOB
        Paraguayan_Guarani,     // PYG
        Guyanese_Dollar,        // GYD
        Surinamese_Dollar,      // SRD
        Falkland_Island_Pound,  // FKP

        None = 0xFF0,
        Bitcoin,         // BTC
        Gold_Ounce,      // XAU
        Silver_Ounce,    // XAG
        Platinum_Ounce,  // XPT
        Palladium_Ounce, // XPD
    };

    static Type& instance();
    static QString toShort(Enum type);
    static QString toShort(QString full);
    static QString toFull(Enum type);
    static QString toFull(QString m_short);
    static Enum fromShort(QString currency);
    static AFlib::Continent continent(QString name);
    static AFlib::Continent continent(Enum type);
    static QStringList allShort();

private:
    Type();
    Type(Type const&) = delete;
    void operator =(Type const&) = delete;

    struct TypeStruct {
        Enum m_enum;
        QString m_full;
        QString m_short;
        AFlib::Continent m_continent;
    };

    QList <TypeStruct> m_list;

    void add(Enum type, QString full, QString short_, AFlib::Continent continent = AFlib::Continent::None);
    inline void addAfrica();
    inline void addEastAsia();
    inline void addWestAsia();
    inline void addEurope();
    inline void addNorthAmerica();
    inline void addOceania();
    inline void addSouthAmerica();
};
}

typedef CurrencyAF::Type::Enum CurrencyEnum;

#endif // CURRENCYAFTYPE_H
