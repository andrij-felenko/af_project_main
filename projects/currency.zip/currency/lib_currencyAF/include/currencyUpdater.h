#ifndef CURRENCYUPDATER_H
#define CURRENCYUPDATER_H

#include <QtNetwork/QAuthenticator>
#include <QtNetwork/QNetworkAccessManager>
#include <QtNetwork/QNetworkReply>
#include "currencyType.h"

namespace CurrencyAF {
    class Updater;
    typedef QSharedPointer <Updater> UpdaterPtr;
}

class CurrencyAF::Updater : public QNetworkAccessManager
{
    Q_OBJECT
public:
    explicit Updater(QObject* parent = nullptr);

    static void date(const QDate& date, QStringList curList);
    static void currencies(QString name);
    static void latest();

protected:
//    static UpdaterPtr m_ptr;
    static UpdaterPtr instance();

    void onRead(QNetworkReply* reply);
    QString m_url;
};

#endif // CURRENCYUPDATER_H
