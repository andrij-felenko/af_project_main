#include "currencyHttpServer.h"
#include <QtCore/QJsonObject>
#include <QtCore/QTimer>

using namespace CurrencyAF;

CurrencyHttpServer::CurrencyHttpServer(QObject *parent) : QObject(parent)
{
    m_server = new QHttpServer(this);

    // init currency data
    m_fixerServer = new AFHostServer(this);
    QTimer::singleShot(2000, this, [=](){
        QDate date = QDate(2010, 1, 1);
        for (int i = 0; i < 1000;){
            date = date.addDays(1);
            qDebug() << "DATE:::" << date;
            if (not ByDate::foundDate(date)){
                m_fixerServer->updateDate(date);
                ++i;
            }
            if (date >= QDate::currentDate())
                break;
        }
    });
    m_fixerServer->updateLatest();

//    m_updater->request();
//    m_updater->request(QDate(2019, 10, 11));
//    m_updater->request();
}

void CurrencyHttpServer::init()
{
//    m_server->route("/getDate/", &CurrencyHttpServer::getDate);
//    m_server->route("/getActual", &CurrencyHttpServer::getActual);
}

int CurrencyHttpServer::listen(const QHostAddress &address, quint16 port)
{
    return m_server->listen(address, port);
}

QJsonObject CurrencyHttpServer::getDate(QString date)
{
    return p_getDate(QDate::fromString(date, "yyyy-MM-dd"));
}

QJsonObject CurrencyHttpServer::p_getDate(QDate date)
{
    auto result = ByDate::collectLatest();
//    auto result = ByDate::collectDate(date);
//    if (result.isEmpty()){
//        m_fixerServer->updateDate(date);
        // TODO wait system to wait until we get it from fixer server
//    }
    return result;
}

QJsonObject CurrencyHttpServer::getActual()
{
    return p_getDate(QDate::currentDate());
}
