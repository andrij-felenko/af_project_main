#ifndef AF_CURRENCY_HTTP_SERVER
#define AF_CURRENCY_HTTP_SERVER

#include "serverHost.h"
#include "qhttpserver.h"
#include "currencyByDate.h"
#include "currencyUpdater.h"

class CurrencyHttpServer : public QObject
{
    Q_OBJECT
public:
    explicit CurrencyHttpServer(QObject* parent = nullptr);
    ~CurrencyHttpServer() = default;

    void init();
    int listen(const QHostAddress &address = QHostAddress::Any, quint16 port = 0);

private:
    QJsonObject getDate(QString date);
    QJsonObject p_getDate(QDate date);
    QJsonObject getActual();
    QHttpServer* m_server;
    AFHostServer* m_fixerServer;
};

#endif // AF_CURRENCY_HTTP_SERVER
