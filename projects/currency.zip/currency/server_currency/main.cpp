#include <QtCore/QCoreApplication>
#include "currencyByDate.h"
#include <QtCore>

#include "currencyHttpServer.h"

int main(int argc, char** argv)
{
    QCoreApplication app(argc, argv);

    CurrencyAF::ByDate::pluginName = "Server_currency";
    CurrencyAF::ByDate::addCurrency(CurrencyAF::Type::allShort());

    CurrencyHttpServer server(&app);
    server.listen(QHostAddress::Any, 55555);

//    QObject::connect(ByDate::instance(), &Updater::result, localUpdater, &ByDate::add);
// CurrencyAF::ByDate::instance(), &Updater::result, this, &ByDate::add);
//    QObject::connect(m_updater, &Updater::finish, this, &ByDate::save);

    return app.exec();
}
