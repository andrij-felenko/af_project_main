#include "serverHost.h"
#include "currencyType.h"
#include "currencyByDate.h"
#include <QtCore/QJsonObject>
#include <QtCore/QJsonDocument>

using namespace CurrencyAF;

AFHostServer::AFHostServer(QObject *parent) : QNetworkAccessManager(parent),
    m_accessKey("?access_key=496299ab5db8dc64e2c8f42bcff5d896"),
    // 33e9a96e437daadfc69cc9495422bb0b dec 0
    // 6b9823a710368c32401bc9515833dbab dec 0
    // 23b9da795607bc2ee760d46a38b61bf7 dec 0
    // 188173f0aec06a1e34121204a4baa613 dec 0
    // 024f408d3d8e4c4f2cebeac3f75638bf dec 0
    // 4193cf026fb7776e88d8cf13c50dc0f5 dec 0
    // 5c82b4e42057cf470451f9434235a9a9 dec 0
    // ecd8747c1d9397f99daa565c8ca66d4b dec 0
    // main: 496299ab5db8dc64e2c8f42bcff5d896
    m_url("http://data.fixer.io/api/"), actualRequest(0)
{
    QObject::connect(this, &QNetworkAccessManager::finished, this, &AFHostServer::onRead);
}

void AFHostServer::updateLatest()
{
    QNetworkRequest request;
    actualRequest++;
    request.setUrl(QUrl(m_url + "latest" + m_accessKey));
    get(request);
}

void AFHostServer::updateDate(const QDate &date)
{
    QNetworkRequest request;
    actualRequest++;
    request.setUrl(QUrl(m_url + date.toString("yyyy-MM-dd") + m_accessKey));
    get(request);
}

void AFHostServer::onRead(QNetworkReply *reply)
{
    QJsonObject obj = QJsonDocument::fromJson(reply->readAll()).object();
    if (not obj.value("success").toBool()){
        qWarning() << "Success false";
        reply->deleteLater();
    }

    if (obj.value("success").toBool()) {
        QDate date = QDate::fromString(obj.value("date").toString(), "yyyy-MM-dd");
        QString base = obj.value("base").toString();
        QJsonObject rateObj = obj.value("rates").toObject();

        if (not obj.value("historical").toBool())
            ByDate::updateLatest(rateObj);
        else {
            QStringList possibleList = Type::allShort();
            for (auto m_short : rateObj.keys())
                if (possibleList.contains(m_short))
                    ByDate::add(date, m_short, rateObj.value(m_short).toDouble());
            ByDate::save();
        }
    }

//    testEqual(rateObj);
    qDebug() << "Current last " << actualRequest << " request.";
    actualRequest--;
    if (actualRequest == 0){
//        ByDate::save();
        ByDate::saveAsJson();
        qDebug() << "ALL END.";
    }
    reply->deleteLater();
}

void AFHostServer::testEqual(QJsonObject rateObj)
{
    QStringList list = rateObj.keys();
    QStringList list2 = CurrencyAF::Type::allShort();
    list.sort();
    list2.sort();
    QStringList allList = list + list2;
    allList.removeDuplicates();
    qDebug() << "name" << list.length() << list2.length();
    for (auto it : allList)
        qDebug() << it << list.contains(it) << list2.contains(it);
    qDebug() << rateObj;
}
